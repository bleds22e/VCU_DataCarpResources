#########################################################
#####   Living Data Project -- Data Management      #####
#####   Workshop 3                                  #####
#####   Check out BWG Database Structure            #####
#########################################################
#####   Self-directed tutorial - do before class    #####
#########################################################

## NOTE ##
## In order to import the data with this script, your working directory needs to
## be set to the correct folder!
## 1. Create a new folder (or use the zip folder you downloaded)
## 2. Make sure this script into the folder you are using.
## 3. Also make sure the BWG_database folder is in the same folder.
## 4. Close and reopen R by opening the this script with RStudio (right-click and
##    select "Open with" -> RStudio. Alternatively, you can also navigate to the 
##    folder in the "Files" tab then clicking "More" (with the gear icon) and 
##    selecting "Set As Working Directory"
## Your working directory should now be set to the correct folder.

## NOTE 2 ##
## This is NOT an assignment for you to turn in! 
## It's just an exercise to get you comfortable with the BWG database.

### SET-UP ---------------------------------------------------------------------

## Working Directory ##

## check if working directory is set to current folder
getwd()   
# if it is not the correct folder, use setwd() to set it to the correct folder
# alternatively, in the panel with the "Files" tab, navigate to the correct folder,
# then click "More" (with the gear next to it), and select "Set As Working Directory"


## Packages ##

## import (or install) required packages
library(tidyverse)

## to install missing packages, go to "Tools" -> "Install Packages..."  ~or~
## run install.packages() with the package name in quotes inside the parentheses
## after installing via either option, run the code above again (library())


## Import Files ##

## make what files are in the BWG database
myfiles <- list.files(path="BWG_database/", pattern = "*.csv", full.names = TRUE)
myfiles

# import all tables as separate data frames, remove file path and file extensions (.csv)
list2env(lapply(setNames(myfiles, make.names(gsub(".*1_", "", tools::file_path_sans_ext(myfiles)))), 
                read_csv), envir = .GlobalEnv)


## DATABASE STRUCTURE ----------------------------------------------------------

## There are many ways to look at data tables you have read into R.

# Point and click options:
# 1. In the "Environment" tab, you can click on the object, which will open a 
#    new window and show the data. 
# 2. You can also click the arrow next to the object to show a quick summary.

# However, we encourage you to examine the data by using code. 
# For example:
# 1. You can use the View() function. This will also open a new window
View(abundance)
View(ownership)

# 2. You can use a number of other functions that will print out in the console.

# examine the structure of an object (these are tibbles--basically a fancy data frame)
str(abundance)
str(bromeliads)

# examine the dimensions of an object
dim(abundance)
dim(visits)

# get a quick summary of an object
summary(abundance)
skimr::skim(abundance)

# look at the first or last few rows of an object
head(abundance)   # default is 6 rows
head(owners, 2)  # you can specify the number you want

tail(traits)

## Using these functions, examine all of the dataframes/tibbles that make up
## the BWG_database. Get a feel for which ones are entities and which ones are
## relationships. Determine which columns are primary keys.